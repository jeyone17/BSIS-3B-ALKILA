function submitForm() {
  // Add your form submission logic here
  alert('Form submitted successfully! Wait for the message or call of the owner. ');
}
