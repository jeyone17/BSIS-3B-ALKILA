function Confirmform() {
  // Add your form submission logic here

  // Redirect to the desired page after form submission
  window.location.href = 'next-page.html';

  // Display a confirmation message (this will be visible momentarily before redirecting)
  alert('Payment Confirmed!!');
}