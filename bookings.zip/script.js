function submitForm() {
  // Add your form submission logic here

  // Redirect to the desired page after form submission
  window.location.href = 'payment.html';
}
