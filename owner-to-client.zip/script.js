function sendMessage(sender) {
    var userInput = document.getElementById("user-input");
    var message = userInput.value;

    if (message.trim() !== "") {
        appendMessage(sender, message);
        userInput.value = "";

        // Simulate a response from the other party
        var recipient = (sender === 'client') ? 'client' : 'client';
        setTimeout(function () {
            appendMessage(recipient, " Hello, I'm interested in your boarding house. Can you provide details on room availability, rates, and application procedures? Thank You. " + recipient + ".");
        }, 500);
    }
}

function appendMessage(sender, message) {
    var chatBox = document.getElementById("chat-box");
    var newMessage = document.createElement("div");
    newMessage.className = "message " + sender;
    newMessage.innerText = message;
    chatBox.appendChild(newMessage);

    // Scroll to the bottom of the chat box
    chatBox.scrollTop = chatBox.scrollHeight;
}
